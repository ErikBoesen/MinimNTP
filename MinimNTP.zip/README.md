# MinimNTP
Minimal new tab page by Erik Boesen.
